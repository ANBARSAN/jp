/**
 * JP CINEMAS - OFFICIAL WEBSITE SCRIPTS
 * Cinematic UI Interactions, GSAP ScrollAnimations, Form Validation
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // 1. Header Sticky Effect & Active Navigation
  const siteHeader = document.querySelector('.site-header');
  const navLinks = document.querySelectorAll('.nav-link, .hero-cta-group a');
  const sections = document.querySelectorAll('section[id]');
  const navbarCollapse = document.querySelector('.navbar-collapse');
  const backToTopBtn = document.getElementById('backToTop');

  const handleScroll = () => {
    const scrollPos = window.scrollY;

    // Sticky header
    if (scrollPos > 60) {
      siteHeader.classList.add('scrolled');
    } else {
      siteHeader.classList.remove('scrolled');
    }

    // Back to top button
    if (backToTopBtn) {
      if (scrollPos > 500) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }

    // Active navigation highlight
    let currentSectionId = '';
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 140;
      const sectionHeight = section.offsetHeight;
      if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
        currentSectionId = section.getAttribute('id');
      }
    });

    document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${currentSectionId}`) {
        link.classList.add('active');
      }
    });
  };

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  // Close mobile navigation on menu item click
  document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
    link.addEventListener('click', () => {
      if (navbarCollapse && navbarCollapse.classList.contains('show')) {
        const bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
        if (bsCollapse) bsCollapse.hide();
      }
    });
  });

  // Back to top click handler
  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // 2. Cinematic Video / Showreel Modal Integration
  const videoModalElement = document.getElementById('cinemaVideoModal');
  const videoModalTitle = document.getElementById('videoModalLabel');
  const videoIframe = document.getElementById('videoPlayerIframe');

  const showreelTriggers = document.querySelectorAll('[data-video-trigger]');
  showreelTriggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const title = btn.getAttribute('data-title') || 'JP Cinemas Cinematic Showreel';
      const videoSrc = btn.getAttribute('data-video-url') || 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?autoplay=1';
      
      if (videoModalTitle) videoModalTitle.textContent = title;
      if (videoIframe) {
        videoIframe.src = videoSrc;
      }
      
      const bsModal = new bootstrap.Modal(videoModalElement);
      bsModal.show();
    });
  });

  if (videoModalElement) {
    videoModalElement.addEventListener('hidden.bs.modal', () => {
      if (videoIframe) {
        videoIframe.src = '';
      }
    });
  }

  // 3. Stills / Posters Gallery Modal Integration
  const galleryModalElement = document.getElementById('stillsGalleryModal');
  const galleryTriggers = document.querySelectorAll('[data-gallery-trigger]');
  galleryTriggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const bsModal = new bootstrap.Modal(galleryModalElement);
      bsModal.show();
    });
  });

  // 4. Toast Notification Utility
  const showToast = (message, title = 'JP Cinemas') => {
    const toast = document.getElementById('liveToast');
    const toastTitle = document.getElementById('toastTitle');
    const toastBody = document.getElementById('toastBody');

    if (toastTitle) toastTitle.textContent = title;
    if (toastBody) toastBody.textContent = message;

    if (toast) {
      toast.classList.add('show');
      setTimeout(() => {
        toast.classList.remove('show');
      }, 5000);
    }
  };

  // Jumaka Information Panels Triggers
  document.querySelectorAll('[data-jumaka-action]').forEach(card => {
    card.addEventListener('click', () => {
      const action = card.getAttribute('data-jumaka-action');
      if (action === 'teaser') {
        const trigger = document.querySelector('#jumaka [data-video-trigger]');
        if (trigger) trigger.click();
      } else if (action === 'posters') {
        const galleryTrigger = document.querySelector('[data-gallery-trigger]');
        if (galleryTrigger) galleryTrigger.click();
      } else if (action === 'songs') {
        showToast('Official musical singles and soundtrack announcement for "Jumaka" releasing soon. Stay tuned to our official handles.', 'Music Announcement');
      } else if (action === 'release') {
        showToast('Theatrical release date for "Jumaka" will be revealed after final sensor and post-production completion.', 'Theatrical Release Update');
      }
    });
  });

  // 5. Contact Form Validation and Submission Handling
  const contactForm = document.getElementById('contactForm');
  const formSuccessAlert = document.getElementById('formSuccessAlert');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      if (!contactForm.checkValidity()) {
        e.stopPropagation();
        contactForm.classList.add('was-validated');
        return;
      }

      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;

      submitBtn.disabled = true;
      submitBtn.innerHTML = `
        <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
        Sending Inquiry...
      `;

      // Simulating seamless client-side verification
      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        contactForm.classList.remove('was-validated');
        contactForm.reset();

        showToast('Thank you for reaching out to JP Cinemas! Your message has been received. Our production team will contact you shortly.', 'Inquiry Received');

        if (formSuccessAlert) {
          formSuccessAlert.classList.remove('d-none');
          setTimeout(() => {
            formSuccessAlert.classList.add('d-none');
          }, 8000);
        }
      }, 1000);
    });
  }

  // 6. GSAP + ScrollTrigger: one reveal system (AOS only handles section headers / newsletter bars)
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const canAnimate = !prefersReducedMotion && typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined';

  if (canAnimate) {
    gsap.registerPlugin(ScrollTrigger);
    const EASE = 'power3.out';

    // Hero entrance (children only: the showcase card keeps its CSS perspective transform)
    gsap.timeline({ defaults: { ease: EASE, duration: 0.9 } })
      .from('.hero-kicker', { y: 16, opacity: 0, duration: 0.6, clearProps: 'transform,opacity' })
      .from('.hero-title', { y: 34, opacity: 0, clearProps: 'transform,opacity' }, '-=0.35')
      .from('.hero-lead', { y: 22, opacity: 0, duration: 0.7, clearProps: 'transform,opacity' }, '-=0.5')
      .from('.hero-buttons > *', { y: 16, opacity: 0, duration: 0.6, stagger: 0.1, clearProps: 'transform,opacity' }, '-=0.4')
      .from('.hero-slides', { opacity: 0, scale: 0.94, duration: 1.1, clearProps: 'transform,opacity' }, 0.2)
      .from('.hero-stats-bar', { y: 24, opacity: 0, duration: 0.8, clearProps: 'transform,opacity' }, '-=0.6');

    // Scroll reveals (small movement, plays once). CSS transitions are paused while GSAP owns the transform.
    const reveal = (selector, { y = 28, stagger = 0.12, start = 'top 88%' } = {}) => {
      const els = gsap.utils.toArray(selector);
      if (!els.length) return;
      els.forEach(el => { el.style.transition = 'none'; });
      gsap.set(els, { opacity: 0, y });
      ScrollTrigger.batch(els, {
        start, once: true,
        onEnter: batch => gsap.to(batch, {
          opacity: 1, y: 0, duration: 0.8, ease: EASE, stagger, overwrite: true, clearProps: 'transform,opacity',
          onComplete: () => batch.forEach(el => { el.style.transition = ''; })
        })
      });
    };
    reveal('.ab-copy > *', { y: 24, stagger: 0.09 });
    reveal('.ab-frame', { y: 34 });
    reveal('.ab-card', { y: 26, stagger: 0.12 });
    reveal('.an-card');
    reveal('.jx-head > *', { y: 24, stagger: 0.09 });
    reveal('.jx-poster', { y: 34 });
    reveal('.jx-teaser, .jx-metabar');
    reveal('.jx-panel', { y: 24, stagger: 0.1 });
    reveal('.sv-card', { y: 26, stagger: 0.09 });
    reveal('.ct-card, .ct-map', { y: 24, stagger: 0.1 });
    reveal('.ct-form', { y: 34 });
    reveal('.fx-col', { y: 20, stagger: 0.1, start: 'top 92%' });

    // Gentle poster parallax on large screens only
    if (gsap.matchMedia) {
      gsap.matchMedia().add('(min-width: 992px)', () => {
        gsap.fromTo('.jx-poster img', { yPercent: -3 }, { yPercent: 3, ease: 'none',
          scrollTrigger: { trigger: '.jx-poster', start: 'top bottom', end: 'bottom top', scrub: 0.6 } });
      });
    }
    window.addEventListener('load', () => ScrollTrigger.refresh());
  }

  // 7. AOS (simple reveals only; none of these elements are animated by GSAP)
  if (typeof AOS !== 'undefined') {
    AOS.init({ duration: 750, easing: 'ease-out-cubic', once: true, offset: 70, mirror: false, disable: prefersReducedMotion });
    window.addEventListener('load', () => AOS.refresh());
  }

  // 8. High-Budget Cinema Background Camera Running Engine
  const initCinemaCameraEngine = () => {
    // A. 24 FPS Live Running Cinema Timecode (HH:MM:SS:FF)
    const timecodeEl = document.getElementById('liveCameraTimecode');
    if (timecodeEl) {
      let hours = 1;
      let minutes = 24;
      let seconds = 19;
      let frames = 14;

      setInterval(() => {
        frames++;
        if (frames >= 24) {
          frames = 0;
          seconds++;
          if (seconds >= 60) {
            seconds = 0;
            minutes++;
            if (minutes >= 60) {
              minutes = 0;
              hours++;
              if (hours >= 24) hours = 0;
            }
          }
        }

        const fStr = frames.toString().padStart(2, '0');
        const sStr = seconds.toString().padStart(2, '0');
        const mStr = minutes.toString().padStart(2, '0');
        const hStr = hours.toString().padStart(2, '0');

        timecodeEl.textContent = `${hStr}:${mStr}:${sStr}:${fStr}`;
      }, 1000 / 24); // Exact 24 FPS cinema cycle (41.67ms)
    }

    // B. Live Dynamic Sound VU Meters
    const vuBarL = document.getElementById('vuBarL');
    const vuBarR = document.getElementById('vuBarR');
    if (vuBarL && vuBarR) {
      let targetL = 65;
      let targetR = 58;
      let currentL = 60;
      let currentR = 55;

      setInterval(() => {
        // Random peak dynamics simulating live studio sound
        if (Math.random() < 0.25) {
          targetL = Math.floor(Math.random() * 45) + 45; // 45% - 90%
          targetR = Math.max(30, Math.min(95, targetL + (Math.random() * 20 - 10)));
        } else {
          targetL = Math.max(25, targetL - 4);
          targetR = Math.max(20, targetR - 4);
        }

        currentL += (targetL - currentL) * 0.35;
        currentR += (targetR - currentR) * 0.35;

        vuBarL.style.width = `${Math.round(currentL)}%`;
        vuBarR.style.width = `${Math.round(currentR)}%`;
      }, 70);
    }

    // C. Studio Multi-Cam Feed Switcher
    const camButtons = document.querySelectorAll('.cam-btn');
    const heroFeedImg = document.getElementById('heroCineFeedImg');
    const feedTitleText = document.getElementById('feedTitleText');

    if (camButtons.length && heroFeedImg) {
      camButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          if (btn.classList.contains('active')) return;

          camButtons.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');

          const newSrc = btn.getAttribute('data-src');
          const newTitle = btn.getAttribute('data-title');
          const camNumber = btn.getAttribute('data-cam');

          // Smooth fade cut transition
          heroFeedImg.style.transition = 'opacity 0.2s ease-in-out';
          heroFeedImg.style.opacity = '0.3';

          setTimeout(() => {
            if (newSrc) heroFeedImg.src = newSrc;
            if (feedTitleText && newTitle) feedTitleText.textContent = newTitle;
            heroFeedImg.style.opacity = '1';
            showToast(`Studio Video Switcher: CAM 0${camNumber} ACTIVE // 4K RAW REC ON`, 'Camera Switcher');
          }, 180);
        });
      });
    }

    // D. Canvas Cinema Background Camera Running Simulation
    const canvas = document.getElementById('cineCameraCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width = (canvas.parentElement ? canvas.parentElement.offsetWidth : window.innerWidth) || 1200;
    let height = canvas.height = (canvas.parentElement ? canvas.parentElement.offsetHeight : 750) || 750;

    const handleResize = () => {
      if (canvas.parentElement) {
        width = canvas.width = canvas.parentElement.offsetWidth;
        height = canvas.height = canvas.parentElement.offsetHeight;
      }
    };
    window.addEventListener('resize', handleResize, { passive: true });

    // Cinematic particle system: anamorphic flare bokeh & golden dust motes
    const particles = [];
    const particleCount = prefersReducedMotion ? 12 : 36;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 3.5 + 1.2,
        speedX: (Math.random() - 0.4) * 0.45,
        speedY: -(Math.random() * 0.35 + 0.15),
        alpha: Math.random() * 0.45 + 0.15,
        pulseSpeed: Math.random() * 0.02 + 0.008,
        pulse: Math.random() * Math.PI,
        color: Math.random() > 0.4 ? 'rgba(242, 140, 18,' : 'rgba(255, 255, 255,'
      });
    }

    let frameStep = 0;

    const render = () => {
      frameStep += 0.015;
      ctx.clearRect(0, 0, width, height);

      // 1. Slow drifting anamorphic focal beam across sensor
      const gradient = ctx.createLinearGradient(
        width * 0.2 + Math.sin(frameStep * 0.5) * 80, 0,
        width * 0.8 + Math.cos(frameStep * 0.4) * 80, height
      );
      gradient.addColorStop(0, 'rgba(242, 140, 18, 0.0)');
      gradient.addColorStop(0.5, 'rgba(242, 140, 18, 0.05)');
      gradient.addColorStop(1, 'rgba(17, 29, 56, 0.0)');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // 2. Render anamorphic lens particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.pulse += p.pulseSpeed;
        const currentAlpha = p.alpha * (0.65 + 0.35 * Math.sin(p.pulse));

        // Draw particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color} ${currentAlpha})`;
        ctx.shadowColor = 'rgba(242, 140, 18, 0.6)';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0; // reset

        // Anamorphic horizontal streak on brighter particles
        if (p.radius > 2.8) {
          ctx.beginPath();
          ctx.moveTo(p.x - p.radius * 6, p.y);
          ctx.lineTo(p.x + p.radius * 6, p.y);
          ctx.strokeStyle = `rgba(242, 140, 18, ${currentAlpha * 0.4})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        // Particle kinematics
        p.x += p.speedX;
        p.y += p.speedY;

        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < -20) p.x = width + 20;
        if (p.x > width + 20) p.x = -20;
      }

      if (!prefersReducedMotion) {
        requestAnimationFrame(render);
      }
    };

    render();
  };

  initCinemaCameraEngine();
});

/* ---- Redesigned navbar + hero behaviour ---- */
document.addEventListener('DOMContentLoaded', () => {
  // Keep "Home" highlighted while the hero is on screen
  const links = document.querySelectorAll('.navbar-nav .nav-link');
  const hero = document.getElementById('hero');
  window.addEventListener('scroll', () => {
    if (hero && window.scrollY < hero.offsetHeight - 160) {
      links.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#home'));
    }
  }, { passive: true });

  // Hero slider (arrows)
  const slides = document.querySelectorAll('.hero-slide');
  let cur = 0;
  const go = n => { slides[cur].classList.remove('active'); cur = (n + slides.length) % slides.length; slides[cur].classList.add('active'); };
  const prev = document.getElementById('heroPrev'), next = document.getElementById('heroNext');
  if (slides.length > 1 && prev && next) {
    prev.addEventListener('click', () => go(cur - 1));
    next.addEventListener('click', () => go(cur + 1));
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) setInterval(() => { if (!document.hidden) go(cur + 1); }, 7000);
  }

  // Search: jump to the first section that matches the query
  const btn = document.getElementById('navSearchBtn'), panel = document.getElementById('navSearchPanel'), input = document.getElementById('navSearchInput');
  if (btn && panel && input) {
    btn.addEventListener('click', () => {
      const open = panel.classList.toggle('open');
      btn.setAttribute('aria-expanded', open);
      if (open) input.focus();
    });
    panel.addEventListener('submit', e => {
      e.preventDefault();
      const q = input.value.trim().toLowerCase();
      if (!q) return;
      const hit = [...document.querySelectorAll('main section[id]')].find(s => s.textContent.toLowerCase().includes(q));
      if (hit) { hit.scrollIntoView({ behavior: 'smooth' }); panel.classList.remove('open'); btn.setAttribute('aria-expanded', false); input.value = ''; }
      else input.setCustomValidity('No match found');
      input.reportValidity(); input.setCustomValidity('');
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { panel.classList.remove('open'); btn.setAttribute('aria-expanded', false); } });
  }
});

/* ---- Announcements carousel + newsletter ---- */
document.addEventListener('DOMContentLoaded', () => {
  const track = document.getElementById('anTrack'), prev = document.getElementById('anPrev'), next = document.getElementById('anNext');
  if (track && prev && next) {
    const step = () => (track.querySelector('.an-card')?.offsetWidth || 300) + 26;
    const sync = () => { const scrolls = track.scrollWidth > track.clientWidth + 4; prev.hidden = next.hidden = !scrolls; };
    prev.addEventListener('click', () => track.scrollBy({ left: -step(), behavior: 'smooth' }));
    next.addEventListener('click', () => track.scrollBy({ left: step(), behavior: 'smooth' }));
    window.addEventListener('resize', sync); sync();
  }
  const form = document.getElementById('newsletterForm'), email = document.getElementById('newsEmail'), msg = document.getElementById('newsMsg');
  if (form && email && msg) {
    const orig = msg.textContent;
    form.addEventListener('submit', e => {
      e.preventDefault();
      const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());
      msg.className = ok ? 'ok' : 'err';
      msg.textContent = ok ? 'Thank you for subscribing to JP Cinemas updates!' : 'Please enter a valid email address.';
      if (ok) email.value = '';
      setTimeout(() => { msg.className = ''; msg.textContent = orig; }, 5000);
    });
  }
});

/* ---- Jumaka: keyboard access for panel cards & poster ---- */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.jx-panel, .jx-poster').forEach(el => {
    el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); } });
  });
});

/* ---- Footer newsletter ---- */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('footerNewsForm'), email = document.getElementById('footerNewsEmail'), msg = document.getElementById('footerNewsMsg');
  if (!form || !email || !msg) return;
  const orig = msg.textContent;
  form.addEventListener('submit', e => {
    e.preventDefault();
    const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim());
    msg.className = ok ? 'ok' : 'err';
    msg.textContent = ok ? 'Thank you for subscribing to JP Cinemas updates!' : 'Please enter a valid email address.';
    if (ok) email.value = '';
    setTimeout(() => { msg.className = ''; msg.textContent = orig; }, 5000);
  });
});
